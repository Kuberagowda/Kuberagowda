# OpenTracing Support

This doc is now available at https://docs.nginx.com/nginx-ingress-controller/third-party-modules/opentracing/